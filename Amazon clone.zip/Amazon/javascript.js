let slideBtnLeft = document.getElementById("slide-btn-left")
let slideBtnRight = document.getElementById("slide-btn-right")

slideBtnLeft.addEventListener("click",()=>{
      alert("left.btn")
})

slideBtnRight.addEventListener("click",()=>{
    alert("right.btn")
})






